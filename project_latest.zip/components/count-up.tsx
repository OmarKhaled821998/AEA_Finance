"use client";

import CountUp from "react-countup";
export { CountUp };
